from .base_exception import GlobalException, CustomException

class DockerConnectException(GlobalException):
    log_level = "ERROR"

    def __init__(self, detail="Docker 연결 실패 (Docker 또는 컨테이너 또는 Database 확인 필요)"):
        super().__init__(status_code=500, detail=detail, code="DB_CONNECTION_ERROR")

class SocialLoginException(CustomException):
    def __init__(self, detail: str = "소셜 로그인 처리 중 오류가 발생했습니다"):
        super().__init__(status_code=400, detail=detail, code="SOCIAL_LOGIN_ERROR")