from .base_exception import CustomException

class AIJsonDecodeException(CustomException):
    def __init__(self, detail: str = "AI 응답이 JSON 형식이 아닙니다"):
        super().__init__(status_code=500, detail=detail, code="AI_JSON_ERROR")

class AINullResponseException(CustomException):
    def __init__(self, detail: str = "AI가 유효한 값을 반환하지 않았습니다"):
        super().__init__(status_code=500, detail=detail, code="AI_EMPTY_RESPONSE")