import logging
import sys
import os

def setup_logging():
    os.makedirs("logs", exist_ok=True)  # logs 디렉토리가 없으면 생성

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler("logs/app.log")
        ]
    )

# 전역에서 사용할 logger
logger = logging.getLogger("capstone")